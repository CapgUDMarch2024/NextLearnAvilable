package com.techweb.demo;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

 import io.swagger.v3.oas.annotations.Operation;
 import io.swagger.v3.oas.annotations.responses.ApiResponse;
 import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Servlet implementation class HelloWorldServlet
 */
@WebServlet("/hello")
public class HelloWorldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	  @Operation(summary = "Say hello", description = "Returns a greeting message.")
	    @ApiResponses(value = {
	        @ApiResponse(responseCode = "200", description = "Successful response"),
	        @ApiResponse(responseCode = "500", description = "Internal server error")
	    })
	  
	    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    	response.setContentType("text/plain");
	    	response.getWriter().write("Hello, World!");
	    //	request.getRequestDispatcher("swagger-ui.html").forward(request, response);
	}

}
