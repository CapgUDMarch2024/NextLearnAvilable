package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Servlet implementation class OpenApiServlet
 */
public class OpenApiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Set response type to application/json
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        // Example static OpenAPI JSON (replace with actual file or generated content)
        String openApiJson = "{\n" +
            "  \"openapi\": \"3.0.0\",\n" +
            "  \"info\": {\n" +
            "    \"title\": \"My API\",\n" +
            "    \"version\": \"1.0.0\"\n" +
            "  },\n" +
            "  \"paths\": {\n" +
            "    \"/hello\": {\n" +
            "      \"get\": {\n" +
            "        \"summary\": \"Hello World endpoint\",\n" +
            "        \"responses\": {\n" +
            "          \"200\": {\n" +
            "            \"description\": \"A hello world response\"\n" +
            "          }\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

        // Write the JSON to the response output stream
        response.getWriter().write(openApiJson);
	}

}
