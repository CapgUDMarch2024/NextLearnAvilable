package com.springboot.api.quickstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

//JUnit 5 Framework
//Mockito 4 (Latest)
//AssertJ Library

@SpringBootTest
class SpringbootCourseApiDataApplicationTests {
	@Test
	void contextLoads() {
		assertTrue(true);
	}
}
