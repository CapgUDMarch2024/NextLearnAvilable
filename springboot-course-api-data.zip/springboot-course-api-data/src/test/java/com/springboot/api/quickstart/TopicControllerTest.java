package com.springboot.api.quickstart;

import com.springboot.quick.api.topic.RepositoryService;
import com.springboot.quick.api.topic.Topic;
import com.springboot.quick.api.topic.TopicController;
import com.springboot.quick.api.topic.TopicService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.junit.jupiter.api.Assertions.assertEquals;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(value = TopicController.class)
public class TopicControllerTest {
    private MockMvc mockMvc;
    @InjectMocks
    private TopicController topicController;

    @Mock
    private TopicService topicService;

    @Captor
    private ArgumentCaptor<String> stringArgumentCaptor;

    @Mock
    private RepositoryService topicResponse;

    @BeforeEach
    public void setup(){

        mockMvc = MockMvcBuilders.standaloneSetup(topicController).build();
    }
    @Test
    public void testAddTopic() throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/topics").contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(new Topic("106", "Dell MS116", "Dell optical mouse"))))
                .andReturn();

        Assertions.assertEquals(200, mvcResult.getResponse().getStatus());
    }

    @Test
    public void testGetTopicDetails() throws Exception {
        Topic topic = new Topic("101", "Dell MS116", "Dell MS116 Usb wired optical mouse");
        when(topicService.getTopic(String.valueOf(101))).thenReturn(topic);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/topic/{id}", "101").accept(MediaType.APPLICATION_JSON)).andReturn();

        assertEquals(200, mvcResult.getResponse().getStatus());
        Topic result = new ObjectMapper().readValue(mvcResult.getResponse().getContentAsByteArray(), Topic.class);
        assertEquals(topic.getId(), result.getId());
        assertEquals(topic.getDescription(), result.getDescription());
        assertEquals(topic.getName(), result.getName());
    }

    @Test
    public void testFooDelete() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders
                        .delete("/topics/{id}", "101")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
            .accept(String.valueOf(status().isOk())));
    }

    @Test
    public void testUpdateEmployee() throws Exception {

        Map<String,Object> body = new HashMap<>();
        body.put("id","101");
        body.put("Name","PutTopic");
        body.put("Description","new@Employee.com");

       ObjectMapper objectMapper = new ObjectMapper();

        mockMvc.perform(MockMvcRequestBuilders.put("/topics/{id}",101)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}

