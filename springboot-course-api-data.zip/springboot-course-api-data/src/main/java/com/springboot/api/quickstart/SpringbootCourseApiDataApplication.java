package com.springboot.api.quickstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCourseApiDataApplication {

	public static void main(String[] args) {

		SpringApplication.run(SpringbootCourseApiDataApplication.class, args);
	}

}
