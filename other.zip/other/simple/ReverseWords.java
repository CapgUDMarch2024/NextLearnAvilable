package com.other.simple;

public class ReverseWords {
    public static void main(String[] args) {
        System.out.println(reverseWords("The Sky is Blue"));
        System.out.println(reverseWords("This. is, blue sky!"));
    }
    public static String reverseWords(String string){
        String words[] = string.split(" ");
        String temp = "";
        for(int i = words.length - 1; i >= 0; i--){
            temp += words[i]+" ";
        }
        return temp.trim();
    }
}
