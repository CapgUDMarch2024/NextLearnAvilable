package com.other.simple;

public class ReverseStringWords {
    public static void main(String[] args) {
        System.out.println(reverseWords("The Sky is Blue"));
        System.out.println(reverseWords("This. is, blue sky!"));
    }

    public static String reverseWords(String string){
        String words[] = string.split(" ");
        int last = words.length - 1;
        for(int first = 0; first < last; first++, last--){
            String temp = words[first];
            words[first] = words[last];
            words[last] = temp;
        }
        //In java-8
        String str = String.join(" ", words);
        return str;
    }
}
