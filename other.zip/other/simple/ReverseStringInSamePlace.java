package com.other.simple;

public class ReverseStringInSamePlace {

    public static void reverse(String str)
    {
        int i = str.length() - 1;
        char[] arr = str.toCharArray();
        for(int j = arr.length - 1; j > 0; j--){
            if(arr[j] == ' '){
                swap(arr,i, j);
                i = j - 1;
            }
        }
        System.out.println( new String(arr).toString());
    }

    public static void swap(char[] s,int start, int end){
        while(start > end){
            char temp = s[start];
            s[start] = s[end];
            s[end] = temp;
            start --;
            end++;
        }
    }
    public static void main(String[] args) {
    String str= "My Name is Vivek";
      reverse(str);
    }
}
