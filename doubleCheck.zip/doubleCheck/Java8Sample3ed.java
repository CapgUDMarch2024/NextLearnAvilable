package com.text.doubleCheck;

import java.util.Arrays;

public class Java8Sample3ed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] intArr= {85 , 101 , 120 , 150 ,70};
		
		int count =(int) Arrays.stream(intArr).filter(num -> num > 100).count();
		
		System.out.print(count);
	}

}
