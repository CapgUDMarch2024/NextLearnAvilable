package com.text.doubleCheck;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Java8Second4th {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		
		    String str = "My Name is Vivek aishwarya";
			
			String[] splitStr = str.split(" ");

		//How do you find the frequency of occurrence of each character in all strings using streams?
				 
				Map<Character, Long> charFrequency = Arrays.stream(splitStr)
				                                         .flatMapToInt(CharSequence::chars)
				                                         .mapToObj(c -> (char) c)
				                                         .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
				
				System.out.println("charFrequency"+charFrequency);
				 
			//	How do you find the number of words in all strings combined using streams?
				 
				long wordCount = Arrays.stream(splitStr)
				                     .flatMapToInt(s -> Arrays.stream(s.split("\\s+")).mapToInt(String::length))
				                     .filter(len -> len > 0)
				                     .count();
				
				System.out.println("wordCount"+wordCount);
				 
			//	How do you find the first non-empty string starting with 'a' using streams?
				 
				Optional<String> firstStringStartingWithA = Arrays.stream(splitStr)
				                                                .filter(s -> !s.isEmpty() && s.charAt(0) == 'a')
				                                                .findFirst();
				
				System.out.println("firstStringStartingWithA "+firstStringStartingWithA);

	}

}

