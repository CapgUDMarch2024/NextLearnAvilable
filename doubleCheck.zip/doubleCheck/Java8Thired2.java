package com.text.doubleCheck;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Java8Thired2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        String str = "My Name is Vivek naman";
		
		String[] splitStr = str.split(" ");
		
		
		//How do you find the second most frequent character in all strings using streams?
				 
				Optional<Character> secondMostFrequentChar = Arrays.stream(splitStr)
				                                                 .flatMapToInt(CharSequence::chars)
				                                                 .mapToObj(c -> (char) c)
				                                                 .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
				                                                 .entrySet().stream()
				                                                 .sorted(Map.Entry.<Character, Long>comparingByValue().reversed())
				                                                 .skip(1)
				                                                 .map(Map.Entry::getKey)
				                                                 .findFirst();
				
				System.out.println(secondMostFrequentChar);
				
			//	How do you find the number of palindromic strings in an array using streams?
				 
				long palindromicCount = Arrays.stream(splitStr)
				                            .filter(s -> new StringBuilder(s).reverse().toString().equals(s))
				                            .count();
				
				System.out.println(palindromicCount);

	}

}
