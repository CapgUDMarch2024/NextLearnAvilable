package com.text.doubleCheck;

import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collectors;

public class Java8LogestStringFirst4th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        String str = "My Name is Vivek";
		
		String[] splitStr = str.split(" ");
		
		String longestString = Arrays.stream(splitStr)
                .max(Comparator.comparingInt(String::length))
                .orElse("");
		
		System.out.println("longestString In Array :- " +longestString);
		
		String SortestString = Arrays.stream(splitStr)
                .min(Comparator.comparingInt(String::length))
                .orElse("");
		
		System.out.println("SortestString In Array:- "+SortestString);
		
		//How do you count the number of strings with length greater than 5 in an array using streams?
				 
				long count = Arrays.stream(splitStr)
				                  .filter(s -> s.length() > 4)
				                  .count();
				
				System.out.println("count String length:- "+count);
				 
	//	How do you concatenate all strings in an array into a single string using streams?
				 
				String concatenated = Arrays.stream(splitStr)
				                          .collect(Collectors.joining());
		
				System.out.println("All String in single String:- "+concatenated);
	}

}
