package com.text.doubleCheck;

import java.util.Arrays;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.stream.IntStream;

public class Java8Sample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int[] numbers= {10 , 7 ,8 ,20 ,6};
       
        IntStream stream =Arrays.stream(numbers);
      
        int sum=   Arrays.stream(numbers).sum();
        
        System.out.println(sum);
        
        System.out.println(Arrays.stream(numbers).max().getAsInt());
        
        System.out.println(Arrays.stream(numbers).min().getAsInt());
        
        System.out.println(Arrays.stream(numbers).average().getAsDouble());
        
        int[] evenNum=Arrays.stream(numbers).filter(num -> num % 2==0).toArray();
        
        boolean AllPositive= Arrays.stream(numbers).allMatch(num -> num > 0);
        
        System.out.println(AllPositive);
        //=============== Lambda Expression================================================
        
          //()->System.out.println("Print");
          
          BiFunction<Integer, Integer, Integer> bifun =  (a1 , a2)->(a1+ a2);
          
          Predicate<Integer> pr= n -> n > 98; //check integer number greater then 98
          
          BiPredicate<Integer, Integer> pip= (n1 , n2 ) -> n1 > n2; //operation in two number
        
        
        
	}

}
