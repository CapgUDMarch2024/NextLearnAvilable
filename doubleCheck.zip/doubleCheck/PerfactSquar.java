package com.text.doubleCheck;

import java.util.Scanner;

public class PerfactSquar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner scan =new Scanner(System.in);
	System.out.println("Please enter the number");
	while(true) {
	int num =scan.nextInt();
	System.out.println(IsPerfacrSquare(num));
	}}
    public static boolean IsPerfacrSquare(int num) {
    	for(int i=1 ;i <num/2+1 ;i++) {
    		if(i*i ==num) {
    			return true;
    		}
    	}
    	return false;
    }
}
