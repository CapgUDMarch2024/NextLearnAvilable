package com.text.doubleCheck;

import java.util.Arrays;
import java.util.OptionalDouble;

public class Java8Forth4 {
public static void main(String[] args) {
	//How do you find the average length of strings containing 'e' in an array using streams?
	
	         String str = "My Name is Vivek chapan50";
	
	         String[] splitStr = str.split(" ");
			 
			OptionalDouble averageLength = Arrays.stream(splitStr)
			                                   .filter(s -> s.contains("e"))
			                                  .mapToInt(String::length)
			                                   .average();
			
			System.out.println("averageLength"+averageLength);
			
			//How do you find the longest common prefix among all strings in an array using streams?
			 
			String longestCommonPrefix = Arrays.stream(splitStr)
			                                  .reduce((s1, s2) -> {
			                                      int minLength = Math.min(s1.length(), s2.length());
			                                      int i = 0;
			                                      while (i < minLength && s1.charAt(i) == s2.charAt(i)) {
			                                          i++;
			                                      }
			                                      return s1.substring(0, i);
			                                  })
			                                 .orElse("");
			
			
			System.out.println("longestCommonPrefix"+longestCommonPrefix);
			
			//How do you find the number of strings with unique characters in an array using streams?
			long uniqueCharStringsCount = Arrays.stream(splitStr)
			                                   .filter(s -> s.chars().distinct().count() == s.length())
			                                   .count();
			
			System.out.println("uniqueCharStringsCount"+uniqueCharStringsCount);
			
			//How do you find the number of strings containing at least one digit in an array using streams?
			long digitContainingStringsCount = Arrays.stream(splitStr)
			                                      .filter(s -> s.matches(".*\\d.*"))
			                                      .count();
			
			System.out.println("digitContainingStringsCount"+digitContainingStringsCount);
			
}
}
