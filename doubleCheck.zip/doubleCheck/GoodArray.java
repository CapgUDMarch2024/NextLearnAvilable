package com.text.doubleCheck;
import java.util.HashMap;
import java.util.Map;

public class GoodArray {
    static int findLengthOfGoodArray (int[] arr , int k){
        int length = 0;
        int count = 0;

        Map<Integer, Integer> map = new HashMap<>();
        for(int i = 0; i < arr.length ; i++ ){
            map.put(arr[i] , map.getOrDefault(arr[i] , 0)+1) ;
        }

        for(Map.Entry<Integer, Integer> entry : map.entrySet()){
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

        if((map.size()) < arr.length )
        {
            for(Map.Entry<Integer, Integer> entry : map.entrySet()){
                if(entry.getValue() >= k){
                    length++ ;
                }
                else if((entry.getValue()) > 0 && (entry.getValue() < k)){
                    count++ ;
                }
            }
        }
        return (( k* length) + count) ;
   }
   
    public static void main(String[] args){
//        int[] numArray = {1,2,3,4,5,1,1,2} ;
        int[] numArray = {1,2,1,2,1,2,1,2} ;
        int k = 1;
        int n = findLengthOfGoodArray(numArray , k) ;
        System.out.println("Length of Good Array: " + n);
    }
}