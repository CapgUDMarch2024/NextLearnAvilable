package com.text.doubleCheck;

import java.util.Arrays;
import java.util.Optional;

public class Sample {

	
	public static void main(String[] args) {
		
		String str = "My Name is Vivek";
		
		String[] split = str.split(" ");
		
	   Optional<String> first = Arrays.stream(split).sorted((s,s1)-> s1.length()-s.length()).findFirst();
	
	   System.out.println(first.get());
		
	}
}
